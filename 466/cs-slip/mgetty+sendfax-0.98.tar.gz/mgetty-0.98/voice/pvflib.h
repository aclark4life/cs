/* 
 * pvflib.h
 *
 */

#ifdef MAIN
char pvflib_h[] = "$Id: pvflib.h,v 1.8 1995/03/29 18:27:16 marc Exp $";
#endif

#include <stdio.h>

/* 
 * Samples/sec sent by the modem. This is correct for all three
 * modes used by the ZyXEL.
 */
 
#define RATE 9600

/* nothing to change below this line */

#define PERROR do {                                     \
        perror(command);                                \
        exit(1);                                        \
} while(0)

#define ERRORRETURN(msg) do {                           \
        fprintf(stderr, "%s: %s\n", command, msg);      \
        exit(1);                                        \
} while(0)

#define USAGE(msg) do {                                 \
        fprintf(stderr, "Usage: %s %s\n", command, msg);  \
        exit(1);                                        \
} while(0)

extern char *command;

extern int zget _PROTO((FILE *f));
extern void zput _PROTO((int d, FILE *f));
