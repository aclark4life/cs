char version_h[] = "$Revision: vgetty experimental test release 0.23 / 12Apr95 $";
char * vgetty_version = "experimental test release 0.23 / 12Apr95";
