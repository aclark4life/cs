#! /bin/sh

# This script is responsible for creating a date stamp.
# It should be installed in your voice directory as `speakdate'
# if you have GNU find and the rsynth synthesizer installed.
# Note that this is a hack (the sentence spoken is rather
# ungrammatical), the perl version does a better job.
#
# Input: a filename, passed as $1
#
# Output: a voice file on STDOUT, e.g. adpcm3
#
# This implementation uses GNU find and the rsynth synthesizer.

AMP=2.5

MSG=`find $1 -printf '%TA, %TB %Td, at %Tl %TM %Tp.\n'`

say "$MSG" -r 9600 -L -l - \
| lintopvf | pvfcut -0.5 0 | pvfamp $AMP | pvftoadpcm3
