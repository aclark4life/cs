/* 
 * util.c
 *
 * Contains some useful utilities.
 *
 */

char util_c[] = "$Id: util.c,v 1.1 1995/04/11 19:18:33 marc Exp $";

#include "voice.h"

char *make_path _P2((path, name), char *path, char *name)
	{
	static char result[MAXLINE];
    
	if (name[0] == '/')
		{
		strcpy(result, name);
		}
	else
		{
		strcpy(result, path);
		strcat(result, "/");
		strcat(result, name);
		};

	return(result);
	};

char *make_string _P1((content), char *content)
	{
	char *string;
	
	string = malloc(strlen(content) + 1);

	if (!string)
		{
		lprintf(L_FATAL, "Not enough memory for allocating strings");
		exit(1);
		};
			
	strcpy(string, content);
	return(string);
	};
